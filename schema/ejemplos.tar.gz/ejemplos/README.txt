
Copiar el contenido de la carpeta Multimedias dentro de la carpeta base configurada en el archivo config.php
	Ver en config.php:
		$config['upload_path'] = '';
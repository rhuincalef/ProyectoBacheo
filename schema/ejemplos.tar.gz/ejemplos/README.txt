Para inicializar la aplicación web con datos de prueba, realizar los siguientes pasos:

Primer paso:

Copiar el contenido de la carpeta Multimedias dentro de la carpeta base configurada en el archivo config.php
	Ver en config.php:
		$config['upload_path'] = '';

Segundo paso:

Restaurar el archivo proyectoBacheo_22_02_2018.backup mediante una plataforma de administración de bases de datos PostgreSQL, como por ejemplo PgAdmin. Si se utiliza PgAdmin, ver la base de datos anteriormente configurada en los pasos de instalación en database.php
		$db['default']['database'] = 'proyectoBacheo';
Una vez ubicada la base de datos objetivo, restaurar.
